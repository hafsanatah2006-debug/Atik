import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, Award, Palette, Shirt, Lightbulb, 
  Instagram, Linkedin, Twitter, ArrowRight 
} from 'lucide-react';

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
  details: string;
}

const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: "Quantum Bloom",
    category: "Art",
    image: "/images/art1.jpg",
    description: "Abstract series exploring particle physics through organic forms",
    details: "This mixed media piece captures the beauty of quantum entanglement using layered acrylics and digital overlays. Inspired by wave function collapse."
  },
  {
    id: 2,
    title: "Aether Dress",
    category: "Fashion",
    image: "/images/fashion1.jpg",
    description: "Sustainable couture piece with physics-inspired structural elements",
    details: "Handcrafted emerald silk dress featuring geometric pleats that mimic electron orbits. Featured in conceptual fashion week."
  },
  {
    id: 3,
    title: "Nexus Studio",
    category: "Design",
    image: "/images/design1.jpg",
    description: "Immersive workspace design for creative scientists",
    details: "A holistic interior concept that integrates natural elements with interactive physics demonstrations for inspiration."
  },
  {
    id: 4,
    title: "Symmetry Codex",
    category: "Design",
    image: "/images/design2.jpg",
    description: "Branding and visual identity for a theoretical physics lab",
    details: "Complete visual system merging mathematical precision with artistic expression. Includes logo, posters and digital interfaces."
  }
];

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition - bodyRect - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMenuOpen(false);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate submission
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
      alert("Thank you! Your message has been received. I'll respond soon.");
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/90 backdrop-blur-lg border-b border-emerald-900">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center">
              <span className="text-zinc-950 font-bold text-xl">NJ</span>
            </div>
            <div>
              <div className="font-semibold tracking-tight text-xl">NUSRAT JAHAN ATIKA</div>
              <div className="text-[10px] text-emerald-400 -mt-1">PHYSICS • ART • DESIGN</div>
            </div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-10 text-sm uppercase tracking-widest">
            <button onClick={() => scrollToSection('about')} className="hover:text-emerald-400 transition-colors">About</button>
            <button onClick={() => scrollToSection('journey')} className="hover:text-emerald-400 transition-colors">Journey</button>
            <button onClick={() => scrollToSection('portfolio')} className="hover:text-emerald-400 transition-colors">Portfolio</button>
            <button onClick={() => scrollToSection('passions')} className="hover:text-emerald-400 transition-colors">Passions</button>
            <button onClick={() => scrollToSection('contact')} className="hover:text-emerald-400 transition-colors">Contact</button>
          </div>

          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)} 
            className="md:hidden text-emerald-400"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-zinc-950 border-t border-emerald-900"
            >
              <div className="px-6 py-8 flex flex-col gap-6 text-lg">
                {['about', 'journey', 'portfolio', 'passions', 'contact'].map((section) => (
                  <button 
                    key={section}
                    onClick={() => scrollToSection(section)}
                    className="text-left hover:text-emerald-400 transition-colors capitalize"
                  >
                    {section}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* HERO SECTION */}
      <section className="min-h-screen flex items-center relative pt-20 bg-[radial-gradient(at_50%_30%,rgba(16,185,129,0.12)_0%,transparent_70%)]">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#111_1px,transparent_1px),linear-gradient(to_bottom,#111_1px,transparent_1px)] bg-[size:40px_40px] opacity-40"></div>
        
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-emerald-800 bg-emerald-950/50">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              <span className="uppercase text-xs tracking-[3px] text-emerald-400">BSc Physics • Creative Explorer</span>
            </div>

            <h1 className="text-7xl md:text-8xl font-bold tracking-tighter leading-none">
              NUSRAT<br />
              JAHAN<br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400">ATIKA</span>
            </h1>

            <p className="max-w-md text-xl text-zinc-400">
              Where quantum curiosity meets artistic expression. 
              Blending the precision of physics with the poetry of design.
            </p>

            <div className="flex flex-wrap gap-4">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => scrollToSection('portfolio')}
                className="group flex items-center gap-3 bg-white text-zinc-950 px-8 py-4 rounded-xl font-medium text-sm uppercase tracking-widest hover:bg-emerald-400 transition-all"
              >
                EXPLORE WORK
                <ArrowRight className="group-hover:-rotate-45 transition" />
              </motion.button>
              
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => scrollToSection('contact')}
                className="flex items-center gap-3 border border-emerald-700 hover:border-emerald-400 px-8 py-4 rounded-xl text-sm uppercase tracking-widest transition-all"
              >
                LET'S CONNECT
              </motion.button>
            </div>
          </motion.div>

          {/* Decorative Visual Element */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ 
              opacity: 1, 
              scale: 1,
              rotate: [0, 3, 0]
            }}
            transition={{ 
              duration: 1.4,
              rotate: { duration: 18, repeat: Infinity, ease: "linear" } 
            }}
            className="relative flex justify-center md:justify-end mt-12 md:mt-0"
          >
            <div className="relative w-[300px] h-[380px] md:w-[360px] md:h-[460px]">
              {/* Large stylized monogram */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-[180px] md:text-[220px] font-black tracking-[-12px] text-transparent bg-clip-text bg-gradient-to-br from-emerald-500/30 via-teal-400/20 to-transparent select-none">NJA</div>
              </div>
              
              {/* Orbiting rings */}
              <motion.div 
                className="absolute inset-0 border border-emerald-400/30 rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute inset-[45px] border border-teal-400/20 rounded-full"
                animate={{ rotate: -360 }}
                transition={{ duration: 19, repeat: Infinity, ease: "linear" }}
              />
              
              {/* Accent particles */}
              {[...Array(5)].map((_, i) => (
                <motion.div 
                  key={i}
                  className="absolute w-1.5 h-1.5 bg-emerald-400 rounded-full"
                  style={{
                    left: `${25 + (i % 3) * 22}%`,
                    top: `${30 + Math.floor(i / 2) * 22}%`
                  }}
                  animate={{ 
                    scale: [1, 2.5, 1],
                    opacity: [0.6, 0.9, 0.6]
                  }}
                  transition={{ 
                    duration: 2.6 + i * 0.3, 
                    repeat: Infinity,
                    delay: i * 0.4
                  }}
                />
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 text-xs tracking-widest text-zinc-500"
        >
          SCROLL TO DISCOVER
          <div className="w-px h-12 bg-gradient-to-b from-transparent via-emerald-500 to-transparent"></div>
        </motion.div>
      </section>

      {/* ABOUT SECTION */}
      <section id="about" className="py-24 border-t border-zinc-900">
        <div className="max-w-5xl mx-auto px-6">
          <div className="flex flex-col md:flex-row gap-16 items-center">
            <div className="md:w-5/12">
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="sticky top-28"
              >
                <div className="uppercase tracking-[4px] text-emerald-500 text-sm mb-3">CHAPTER I</div>
                <h2 className="text-6xl font-bold tracking-tighter leading-none">The Story</h2>
                <div className="h-1 w-20 bg-emerald-500 mt-6"></div>
              </motion.div>
            </div>

            <div className="md:w-7/12 space-y-8 text-lg text-zinc-300">
              <p className="leading-relaxed">
                I am Nusrat Jahan Atika, a recent BSc Physics graduate with an insatiable curiosity for the universe's hidden patterns. 
                My academic journey taught me the elegance of equations, but my soul has always been captivated by color, form, and narrative.
              </p>
              <p className="leading-relaxed">
                Today I bridge these worlds — designing garments that echo the symmetry of crystals, creating art that visualizes cosmic phenomena, 
                and crafting spaces that make science feel like magic. For me, physics isn't just formulas on paper — it's the rhythm behind every beautiful thing.
              </p>
              
              <div className="grid grid-cols-3 gap-4 pt-6">
                {[
                  { number: "22", label: "Age" },
                  { number: "1", label: "Degree" },
                  { number: "∞", label: "Ideas" }
                ].map((stat, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-zinc-900/70 border border-emerald-900 p-6 rounded-2xl text-center"
                  >
                    <div className="text-4xl font-mono text-emerald-400 mb-1">{stat.number}</div>
                    <div className="text-xs uppercase tracking-widest text-zinc-500">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* JOURNEY / EDUCATION */}
      <section id="journey" className="py-24 bg-zinc-900/50">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline text-emerald-500 uppercase tracking-widest text-sm">CHAPTER II</div>
            <h2 className="text-6xl font-bold tracking-tighter mt-3">My Journey</h2>
            <p className="mt-4 max-w-md mx-auto text-zinc-400">From lecture halls to late-night sketchbooks</p>
          </div>

          <div className="space-y-20">
            {/* Education Card */}
            <motion.div 
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-zinc-950 border border-emerald-800/60 rounded-3xl p-10 md:p-14 flex flex-col md:flex-row gap-10"
            >
              <div className="md:w-2/5">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                    <Award className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="text-emerald-400 text-sm tracking-widest">EDUCATION</div>
                    <div className="text-3xl font-semibold mt-2">BACHELOR OF SCIENCE</div>
                  </div>
                </div>
              </div>
              
              <div className="md:w-3/5 space-y-6 text-zinc-300">
                <div>
                  <div className="font-medium">Physics • University of Dhaka</div>
                  <div className="text-sm text-zinc-500 mt-1">2019 — 2024</div>
                </div>
                
                <p className="leading-relaxed">
                  Graduated with honors focusing on quantum mechanics and materials science. 
                  My thesis explored the visual representation of wave-particle duality using generative art techniques.
                </p>
                
                <div className="flex gap-3 flex-wrap">
                  {["Quantum Mechanics", "Electromagnetism", "Thermodynamics", "Research Methods"].map((course, i) => (
                    <div key={i} className="bg-zinc-900 px-4 py-1 text-xs rounded-full border border-zinc-800">{course}</div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Transition Note */}
            <div className="text-center text-sm max-w-xs mx-auto text-zinc-500 tracking-widest">
              THE PATH BETWEEN TWO WORLDS
            </div>
          </div>
        </div>
      </section>

      {/* PORTFOLIO */}
      <section id="portfolio" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-end mb-16">
            <div>
              <div className="text-emerald-400 uppercase tracking-[3px] text-sm">CHAPTER III</div>
              <h2 className="text-6xl font-bold tracking-tighter">Selected Works</h2>
            </div>
            <div className="hidden md:block text-zinc-500 max-w-[240px] text-sm">
              Each project represents a beautiful collision between scientific precision and creative intuition
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {portfolioItems.map((item, index) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, y: 80 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -12 }}
                onClick={() => setSelectedItem(item)}
                className="group relative bg-zinc-900 rounded-3xl overflow-hidden cursor-pointer border border-zinc-800 hover:border-emerald-700 transition-all duration-500"
              >
                <div className="aspect-[16/13] relative">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-zinc-950/90"></div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-8">
                    <div className="uppercase text-emerald-400 text-xs tracking-widest mb-2">{item.category}</div>
                    <h3 className="text-4xl font-semibold tracking-tight mb-3">{item.title}</h3>
                    <p className="text-zinc-400 text-sm line-clamp-2">{item.description}</p>
                  </div>
                  
                  <div className="absolute top-6 right-6 bg-black/70 text-emerald-400 text-[10px] px-3 py-1 rounded-full flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                    VIEW PROJECT <ArrowRight size={13} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-16 text-xs tracking-widest text-emerald-600">MORE IN THE ARCHIVES — CURRENTLY CURATING NEW WORK</div>
        </div>
      </section>

      {/* PASSIONS / INTERESTS */}
      <section id="passions" className="py-24 bg-zinc-900">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-20">
            <div className="text-emerald-400 text-sm tracking-[4px] mb-4">CHAPTER IV • ONGOING EXPLORATIONS</div>
            <h2 className="text-6xl font-bold tracking-tighter">Passions &amp; Interests</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Palette className="w-9 h-9" />,
                title: "Visual Arts",
                desc: "Abstract painting, digital generative art, photography. Always exploring the intersection of chaos theory and beauty.",
                color: "emerald"
              },
              {
                icon: <Shirt className="w-9 h-9" />,
                title: "Fashion Design",
                desc: "Sustainable fashion. Garments with hidden scientific references and movement that mimics natural phenomena.",
                color: "teal"
              },
              {
                icon: <Lightbulb className="w-9 h-9" />,
                title: "Creative Science",
                desc: "Science communication through visuals. Infographics, interactive installations, and sci-art exhibitions.",
                color: "cyan"
              }
            ].map((passion, index) => (
              <motion.div 
                key={index}
                whileHover={{ scale: 1.02, rotate: 1 }}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.15 }}
                className={`bg-zinc-950 border border-zinc-800 hover:border-${passion.color}-600 p-10 rounded-3xl group transition-all`}
              >
                <div className={`text-${passion.color}-400 mb-8`}>{passion.icon}</div>
                <h3 className="text-3xl font-semibold mb-5 tracking-tight">{passion.title}</h3>
                <p className="text-zinc-400 leading-relaxed">{passion.desc}</p>
                
                <div className="mt-8 pt-8 border-t border-zinc-800 text-xs text-zinc-500 flex items-center justify-between">
                  EXPLORE MORE 
                  <span className="text-xl group-hover:translate-x-1 transition">↗</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="py-24 border-t border-zinc-900 relative">
        <div className="max-w-4xl mx-auto px-6">
          <div className="grid md:grid-cols-5 gap-16">
            <div className="md:col-span-2">
              <h2 className="text-6xl font-bold tracking-[-2px] leading-none">Let's create something<br />extraordinary together.</h2>
              
              <div className="mt-12 space-y-8">
                <div>
                  <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">EMAIL</div>
                  <a href="mailto:hello@nusratjahana.com" className="block text-xl hover:text-emerald-400 transition">hello@nusratjahana.com</a>
                </div>
                
                <div>
                  <div className="text-xs uppercase tracking-widest text-zinc-500 mb-2">BASED IN</div>
                  <div className="text-xl">Dhaka, Bangladesh</div>
                </div>
              </div>
            </div>

            <div className="md:col-span-3">
              <form onSubmit={handleFormSubmit} className="space-y-8">
                <div>
                  <label className="block text-xs tracking-widest text-zinc-500 mb-3">YOUR NAME</label>
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-transparent border-b border-zinc-700 pb-4 text-xl focus:outline-none focus:border-emerald-400 placeholder:text-zinc-600"
                    placeholder="Alex Rivera"
                  />
                </div>
                
                <div>
                  <label className="block text-xs tracking-widest text-zinc-500 mb-3">YOUR EMAIL</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full bg-transparent border-b border-zinc-700 pb-4 text-xl focus:outline-none focus:border-emerald-400 placeholder:text-zinc-600"
                    placeholder="you@creative.co"
                  />
                </div>
                
                <div>
                  <label className="block text-xs tracking-widest text-zinc-500 mb-3">YOUR MESSAGE</label>
                  <textarea 
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    className="w-full bg-transparent border-b border-zinc-700 pb-4 text-xl focus:outline-none focus:border-emerald-400 placeholder:text-zinc-600 resize-y min-h-[140px]"
                    placeholder="I'm reaching out because..."
                  ></textarea>
                </div>

                <motion.button 
                  type="submit"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.985 }}
                  disabled={isSubmitted}
                  className="w-full bg-white hover:bg-emerald-400 active:bg-white text-zinc-950 py-6 text-sm tracking-[3px] font-medium rounded-2xl flex items-center justify-center gap-3 transition disabled:opacity-70"
                >
                  {isSubmitted ? "SENDING TRANSMISSION..." : "SEND MESSAGE"}
                  {!isSubmitted && <ArrowRight />}
                </motion.button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-black py-16 border-t border-zinc-900">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-12 gap-y-16">
          <div className="md:col-span-5">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-xs text-black font-black">NJ</div>
              <div className="font-mono text-xs text-emerald-400">NJA STUDIO</div>
            </div>
            
            <p className="max-w-xs text-sm text-zinc-500">Science. Art. Fashion.<br />Always in motion.</p>
          </div>
          
          <div className="md:col-span-3 text-sm">
            <div className="uppercase tracking-widest text-emerald-500 mb-6">QUICK LINKS</div>
            <div className="space-y-3 text-zinc-400">
              <button onClick={() => scrollToSection('about')} className="block hover:text-white">About Me</button>
              <button onClick={() => scrollToSection('portfolio')} className="block hover:text-white">Portfolio</button>
              <button onClick={() => scrollToSection('passions')} className="block hover:text-white">Passions</button>
            </div>
          </div>
          
          <div className="md:col-span-4">
            <div className="uppercase tracking-widest text-emerald-500 mb-6">CONNECT WITH ME</div>
            
            <div className="flex gap-6 text-2xl">
              {[Instagram, Linkedin, Twitter].map((Icon, i) => (
                <motion.a 
                  key={i}
                  href="#" 
                  whileHover={{ y: -4, color: "#10b981" }}
                  className="text-zinc-400 hover:text-emerald-400"
                >
                  <Icon />
                </motion.a>
              ))}
            </div>
            
            <div className="mt-16 text-[10px] text-zinc-600">
              © {new Date().getFullYear()} NUSRAT JAHAN ATIKA. ALL RIGHTS RESERVED.<br />
              MADE WITH PHYSICS &amp; PASSION<br />
              CREATED BY HAFSA
            </div>
          </div>
        </div>
      </footer>

      {/* PORTFOLIO MODAL */}
      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-6" onClick={() => setSelectedItem(null)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-zinc-900 max-w-4xl w-full rounded-3xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative">
                <img 
                  src={selectedItem.image} 
                  alt={selectedItem.title} 
                  className="w-full h-[460px] object-cover"
                />
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-6 right-6 bg-black/70 hover:bg-zinc-800 w-12 h-12 rounded-full flex items-center justify-center"
                >
                  <X />
                </button>
              </div>
              
              <div className="p-12">
                <div className="flex items-center gap-4 mb-3">
                  <div className="px-4 py-1 text-xs border border-emerald-700 text-emerald-400 rounded-full">{selectedItem.category}</div>
                </div>
                
                <h3 className="text-5xl font-bold tracking-tighter mb-6">{selectedItem.title}</h3>
                
                <div className="prose prose-zinc prose-invert max-w-none text-lg">
                  {selectedItem.details}
                </div>
                
                <div className="pt-8 mt-12 border-t border-zinc-800 flex justify-between items-center text-sm">
                  <div>PROJECT ARCHIVE — 2023</div>
                  <button 
                    onClick={() => setSelectedItem(null)}
                    className="px-8 py-3.5 border border-white/60 hover:bg-white hover:text-zinc-900 transition rounded-full"
                  >
                    CLOSE WINDOW
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;

